PACKAGE UNDER CONSTRUCTION. 

Usage:

```python
pip install FastKmedoids --upgrade
```

```python
import FastKmedoids
from FastKmedoids import package_status
```

```python
package_status()
```